# raster_barcode/__init__.py
import os
import platform

from .libbarpy import *  # Import symbols from the .pyd file
